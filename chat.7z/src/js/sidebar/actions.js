import constants from '../../constants/constants';

export const toggleChatModule = () => ({ type: constants.TOGGLE_CHAT_MODULE });