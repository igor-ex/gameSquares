import { connect } from 'react-redux';
import Component from './Header.jsx';

const mapStateToProps = state => ({
});

const mapDispatchToProps = dispatch => ({
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
