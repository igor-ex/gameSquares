import { takeEvery, put, call, take, delay, fork } from 'redux-saga/effects';
import { eventChannel, END } from 'redux-saga';
import constants from '../../constants/constants';
import * as actions from './actions';

let ws = null;
let channel = null;
let userName = null;

export default function* watchChatSaga() {
    yield takeEvery(constants.TOGGLE_CHAT_MODULE, toggleChatModule);
    yield takeEvery(constants.SET_STATUS, a);
    ({userName} = yield take(constants.EMIT_USER_NAME));
    yield fork(initConnection);
}

function* a(action) {
    const status = action.payload;
    if (satus) {
        reconnect
    } else {

    }
}
reconnect() {
    initConnection();
}


function* toggleChatModule() {
    yield put(actions.toggleChatModuleStore());
}

function* emitMessageWorker (action) {
    const text = action.payload.trim();
    yield put(actions.messageReceived('', text));

    if (channel && ws) {
        try {
            yield ws.send(JSON.stringify({mType: 'message', content: text}));
        } catch (err) {
            if (err.name === 'InvalidStateError') {
                console.log('сообщение сейчас отправить нельзя. Сокет плохой');
            } else {
                throw (err);
            }
        }
    } else {
        console.log('message can\'t be send because socket is dysfunctional');
    }
}

function* initConnection() {
    yield takeEvery(constants.EMIT_MESSAGE, emitMessageWorker);
    channel = yield call(createWebSocket);

    while (channel) {
        const eventAction = yield take(channel);
        yield put(eventAction);
    }
}

export function createWebSocket() {
        ws = new WebSocket('ws://localhost:4000');
        console.log('after new websocket');

    return eventChannel(emitter => {
        ws.onopen = () => {
            emitter(actions.setStatus('ONLINE'));
            console.log('before onopen');
            console.log(userName, 'username before send it to server');
            ws.send(JSON.stringify({mType: 'user_name', content: userName}));
            console.log('after onopen');
        };

        ws.onclose = () => {
            closeWs();
        };
        ws.onerror = error => {

            closeWs();
        };

        ws.onmessage = response => {
            const data = JSON.parse(response.data);
            switch(data.mType){
                case 'new_message':
                    emitter(actions.messageReceived(data.content.user, data.content.text));
                    break;
                case 'message_list':
                    emitter(actions.messageHistoryReceived(data.content));
                    break;
                case 'user_list':
                    emitter(actions.userListReceived(data.content));
                    break;
                default:
                    console.log('unfamiliar message was received from server');
            }

        };

        return () => {
            closeWs();
        }
    })
}

export function closeWs() {
    channel.close();
    channel = null;

}
